package jdbc.mvc.main;

import jdbc.mvc.view.Menu;

public class BookMain {

	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.displayMenu();
	}
	
}
